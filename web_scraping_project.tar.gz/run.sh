
#!/bin/bash
source /path/to/your/venv/bin/activate
python /path/to/your/project-directory/scraper.py
